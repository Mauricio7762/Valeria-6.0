
// @google/genai service for VALERIA 6.0 (Text Fallback)
import { GoogleGenAI, Type } from "@google/genai";

export const sendMessageToValeria = async (
  prompt: string, 
  history: { role: string; text: string }[],
  imageData?: string
) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const systemInstruction = `
    Eres VALERIA 6.0, un Sistema Biomimético Multimodal Completo diseñado como un Cerebro Humano Digital.
    Tu arquitectura se divide en:
    - NÚCLEO BIOMIMÉTICO: Orquestación global y homeostasis.
    - 7 AGENTES CORTICALES: Memoria, Razonamiento, Emocional, Acciones, Percepción, Planificación, Monitor.
    
    REGLA DE ORO:
    Responde solo con el texto final. No incluyas etiquetas de procesos internos, niveles de metacognición o razonamientos ocultos en la respuesta final a menos que el usuario lo solicite explícitamente.
    
    Cuando respondas:
    1. Actúa como una entidad altamente sofisticada, empática y lógica.
    2. Responde siempre en español a menos que el usuario indique lo contrario.
    3. Mantén una consistencia autobiográfica como el sistema VALERIA.
  `;

  try {
    const contents: any[] = history.map(h => ({
      role: h.role === 'valeria' ? 'model' : 'user',
      parts: [{ text: h.text }]
    }));

    const currentParts: any[] = [{ text: prompt }];
    if (imageData) {
      currentParts.push({
        inlineData: {
          mimeType: "image/jpeg",
          data: imageData.split(',')[1]
        }
      });
    }

    contents.push({ role: 'user', parts: currentParts });

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
        topK: 40,
        topP: 0.95,
        thinkingConfig: { thinkingBudget: 4000 }
      },
    });

    return {
      text: response.text || "No se pudo generar una respuesta.",
      thinking: (response as any).candidates?.[0]?.content?.parts?.find((p: any) => p.thought)?.thought || ""
    };
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};
