
import React, { useEffect, useRef } from 'react';
import { SystemMood } from '../types';

interface VoiceVisualizerProps {
  analyser: AnalyserNode | null;
  isListening: boolean;
  isResponding: boolean;
  mood: SystemMood;
}

const VoiceVisualizer: React.FC<VoiceVisualizerProps> = ({ analyser, isListening, isResponding, mood }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestRef = useRef<number>(null);

  const getMoodColors = (mood: SystemMood) => {
    switch (mood) {
      case 'analytical': return ['#a855f7', '#3b82f6']; // Purple/Blue
      case 'processing': return ['#3b82f6', '#2dd4bf']; // Blue/Teal
      case 'emotional': return ['#f43f5e', '#fb7185']; // Rose
      case 'alert': return ['#f59e0b', '#ef4444']; // Amber/Red
      default: return ['#3b82f6', '#1d4ed8']; // Standard Blue
    }
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const bufferLength = analyser ? analyser.frequencyBinCount : 64;
    const dataArray = new Uint8Array(bufferLength);

    const draw = () => {
      const width = canvas.width;
      const height = canvas.height;
      const centerX = width / 2;
      const centerY = height / 2;
      const radius = Math.min(width, height) * 0.25;

      ctx.clearRect(0, 0, width, height);

      if (analyser) {
        analyser.getByteFrequencyData(dataArray);
      } else if (isListening || isResponding) {
        // Mock data if no analyser yet
        for (let i = 0; i < bufferLength; i++) {
          dataArray[i] = 20 + Math.random() * 30;
        }
      } else {
        // Idle pulse
        const time = Date.now() * 0.002;
        for (let i = 0; i < bufferLength; i++) {
          dataArray[i] = 10 + Math.sin(time + i * 0.1) * 5;
        }
      }

      const colors = getMoodColors(mood);
      const gradient = ctx.createRadialGradient(centerX, centerY, radius * 0.8, centerX, centerY, radius * 1.5);
      gradient.addColorStop(0, colors[0]);
      gradient.addColorStop(1, colors[1] + '00');

      // Draw outer glow
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius * (1.1 + (isListening || isResponding ? 0.1 : 0)), 0, Math.PI * 2);
      ctx.shadowBlur = 40;
      ctx.shadowColor = colors[0];
      ctx.strokeStyle = colors[0] + '33';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Draw circular waveform
      ctx.beginPath();
      ctx.shadowBlur = 0;
      for (let i = 0; i < bufferLength; i++) {
        const angle = (i / bufferLength) * Math.PI * 2;
        const amplitude = (dataArray[i] / 255) * (isResponding ? 80 : 40);
        const r = radius + amplitude;
        const x = centerX + Math.cos(angle) * r;
        const y = centerY + Math.sin(angle) * r;

        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.strokeStyle = colors[0];
      ctx.lineWidth = 3;
      ctx.lineJoin = 'round';
      ctx.stroke();
      
      // Secondary inner layer
      ctx.beginPath();
      for (let i = 0; i < bufferLength; i++) {
        const angle = (i / bufferLength) * Math.PI * 2;
        const amplitude = (dataArray[i] / 255) * (isResponding ? 40 : 20);
        const r = radius - 10 + amplitude;
        const x = centerX + Math.cos(angle) * r;
        const y = centerY + Math.sin(angle) * r;

        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.strokeStyle = colors[1] + '88';
      ctx.lineWidth = 1;
      ctx.stroke();

      // Center Core
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius * 0.7, 0, Math.PI * 2);
      ctx.fillStyle = colors[0] + '11';
      ctx.fill();

      requestRef.current = requestAnimationFrame(draw);
    };

    draw();
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [analyser, isListening, isResponding, mood]);

  return (
    <div className="w-full h-full flex items-center justify-center relative group">
      <canvas 
        ref={canvasRef} 
        width={600} 
        height={600} 
        className="max-w-full max-h-full transition-transform duration-700" 
      />
      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
        <div className={`text-xs font-mono tracking-[0.3em] uppercase transition-opacity duration-500 ${isListening ? 'opacity-100 text-blue-400' : isResponding ? 'opacity-100 text-purple-400' : 'opacity-30'}`}>
          {isListening ? 'Escuchando' : isResponding ? 'Transmitiendo' : 'Valeria 6.0'}
        </div>
      </div>
    </div>
  );
};

export default VoiceVisualizer;
