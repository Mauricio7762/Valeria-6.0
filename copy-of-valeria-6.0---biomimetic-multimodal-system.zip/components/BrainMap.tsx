
import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { CorticalAgentType } from '../types';

interface BrainMapProps {
  activeAgent: CorticalAgentType | null;
}

const BrainMap: React.FC<BrainMapProps> = ({ activeAgent }) => {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current) return;

    const width = svgRef.current.clientWidth;
    const height = svgRef.current.clientHeight;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    // Fix: Explicitly type nodes as any[] to support mixed CorticalAgentType and 'NUCLEO' IDs
    const nodes: any[] = Object.values(CorticalAgentType).map((name, i) => ({
      id: name,
      group: i,
      x: width / 2 + Math.cos((i / 7) * 2 * Math.PI) * 150,
      y: height / 2 + Math.sin((i / 7) * 2 * Math.PI) * 100,
    }));

    const links: any[] = [];
    nodes.forEach((node, i) => {
      nodes.forEach((other, j) => {
        if (i < j) links.push({ source: node.id, target: other.id, value: 1 });
      });
    });

    // Central "Core" node - successfully pushed as nodes is now typed to allow string IDs
    nodes.push({ id: 'NUCLEO', group: 10, x: width / 2, y: height / 2 });
    nodes.forEach(node => {
        // Fix: Comparison between node.id and 'NUCLEO' is now safe due to widened typing
        if (node.id !== 'NUCLEO') links.push({ source: 'NUCLEO', target: node.id, value: 2 });
    });

    const simulation = d3.forceSimulation(nodes as any)
      .force("link", d3.forceLink(links).id((d: any) => d.id).distance(120))
      .force("charge", d3.forceManyBody().strength(-300))
      .force("center", d3.forceCenter(width / 2, height / 2));

    const link = svg.append("g")
      .attr("stroke", "rgba(75, 85, 99, 0.2)")
      .selectAll("line")
      .data(links)
      .join("line")
      .attr("stroke-width", d => Math.sqrt((d as any).value));

    const node = svg.append("g")
      .selectAll("g")
      .data(nodes)
      .join("g");

    node.append("circle")
      .attr("r", (d: any) => d.id === 'NUCLEO' ? 25 : 12)
      .attr("fill", (d: any) => {
        if (d.id === activeAgent) return "#3b82f6";
        return d.id === 'NUCLEO' ? "#1e40af" : "#1f2937";
      })
      .attr("stroke", "#3b82f6")
      .attr("stroke-width", (d: any) => d.id === activeAgent ? 4 : 1)
      .attr("class", (d: any) => d.id === activeAgent ? "pulse" : "");

    node.append("text")
      .text((d: any) => d.id)
      .attr("x", 15)
      .attr("y", 5)
      .attr("fill", "rgba(255, 255, 255, 0.6)")
      .attr("font-size", "10px")
      .style("pointer-events", "none");

    simulation.on("tick", () => {
      link
        .attr("x1", (d: any) => d.source.x)
        .attr("y1", (d: any) => d.source.y)
        .attr("x2", (d: any) => d.target.x)
        .attr("y2", (d: any) => d.target.y);

      node.attr("transform", (d: any) => `translate(${d.x},${d.y})`);
    });

    return () => simulation.stop();
  }, [activeAgent]);

  return (
    <div className="w-full h-full relative">
      <svg ref={svgRef} className="w-full h-full" />
      <div className="absolute top-4 left-4 text-xs font-mono text-blue-400 bg-blue-900/20 px-2 py-1 border border-blue-500/30 rounded">
        SISTEMA NERVIOSO CENTRAL: ACTIVO
      </div>
    </div>
  );
};

export default BrainMap;
