
import React from 'react';
import { AgentStatus } from '../types';
import { AGENT_CONFIGS } from '../constants';

interface AgentCardProps {
  status: AgentStatus;
}

const AgentCard: React.FC<AgentCardProps> = ({ status }) => {
  const config = AGENT_CONFIGS[status.id];

  return (
    <div className="glass-panel p-4 rounded-xl flex flex-col gap-3 transition-all hover:border-blue-500/50 group">
      <div className="flex items-center justify-between">
        <div className={`w-10 h-10 rounded-lg ${config.bg} flex items-center justify-center ${config.color} text-lg`}>
          {config.icon}
        </div>
        <div className="flex flex-col items-end">
          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${status.isActive ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'}`}>
            {status.isActive ? 'ONLINE' : 'IDLE'}
          </span>
          <span className="text-[10px] text-gray-500 mt-1">{status.latency}ms</span>
        </div>
      </div>
      
      <div>
        <h3 className="font-semibold text-sm text-gray-200">{status.id}</h3>
        <p className="text-[10px] text-gray-500 line-clamp-1">{status.description}</p>
      </div>

      <div className="space-y-2">
        <div className="flex justify-between text-[10px]">
          <span className="text-gray-400 uppercase">Carga Sináptica</span>
          <span className="text-gray-200 font-mono">{status.load}%</span>
        </div>
        <div className="h-1 bg-gray-800 rounded-full overflow-hidden">
          <div 
            className={`h-full ${status.load > 80 ? 'bg-red-500' : 'bg-blue-500'} transition-all duration-500`}
            style={{ width: `${status.load}%` }}
          />
        </div>
      </div>

      <div className="flex items-center gap-1 text-[10px] text-gray-400">
        <div className={`w-1.5 h-1.5 rounded-full ${status.health > 90 ? 'bg-green-400' : 'bg-yellow-400'}`}></div>
        Salud del Agente: {status.health}%
      </div>
    </div>
  );
};

export default AgentCard;
