
import React, { useState, useEffect, useRef } from 'react';
import { 
  CorticalAgentType, 
  AgentStatus, 
  SystemMetrics, 
  ChatMessage, 
  SystemMood
} from './types';
import { INITIAL_METRICS } from './constants';
import BrainMap from './components/BrainMap';
import AgentCard from './components/AgentCard';
import VoiceVisualizer from './components/VoiceVisualizer';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';

const MEMORY_KEY = 'VALERIA_LONG_TERM_MEMORY_V6';

const App: React.FC = () => {
  const [isChatVisible, setIsChatVisible] = useState(false);
  const [isDashboardVisible, setIsDashboardVisible] = useState(false);
  const [showInstallGuide, setShowInstallGuide] = useState(false);
  const [isStandalone, setIsStandalone] = useState(false);
  const [isBlobUrl, setIsBlobUrl] = useState(false);
  const [mood, setMood] = useState<SystemMood>('calm');
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  
  const [agents] = useState<AgentStatus[]>([
    { id: CorticalAgentType.MEMORY, isActive: true, load: 10, latency: 5, health: 100, description: 'Capa de Persistencia' },
    { id: CorticalAgentType.REASONING, isActive: true, load: 5, latency: 40, health: 100, description: 'Núcleo de Inferencia' },
    { id: CorticalAgentType.EMOTIONAL, isActive: true, load: 5, latency: 5, health: 100, description: 'Balance Afectivo' },
    { id: CorticalAgentType.ACTIONS, isActive: true, load: 0, latency: 0, health: 100, description: 'Interface de Control' },
    { id: CorticalAgentType.PERCEPTION, isActive: true, load: 20, latency: 100, health: 100, description: 'Sensor de Voz' },
    { id: CorticalAgentType.PLANNING, isActive: false, load: 0, latency: 0, health: 100, description: 'Proyección' },
    { id: CorticalAgentType.MONITOR, isActive: true, load: 2, latency: 2, health: 100, description: 'Homeostasis' },
  ]);
  
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem(MEMORY_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return parsed.map((m: any) => ({ ...m, timestamp: new Date(m.timestamp) }));
      } catch (e) { return []; }
    }
    return [{ id: 'init', role: 'valeria', text: 'VALERIA 6.0 activa. Lista para el enlace neuronal.', timestamp: new Date() }];
  });

  const [inputText, setInputText] = useState('');
  const [isSessionActive, setIsSessionActive] = useState(false);
  const [isResponding, setIsResponding] = useState(false);

  // Audio refs
  const outputAudioCtxRef = useRef<AudioContext | null>(null);
  const inputAudioCtxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const liveSessionRef = useRef<any>(null);
  const nextStartTimeRef = useRef<number>(0);
  const audioSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const chatEndRef = useRef<HTMLDivElement>(null);
  
  const sessionActiveRef = useRef(false);

  useEffect(() => {
    const isModeStandalone = window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone === true;
    setIsStandalone(isModeStandalone);
    
    // Detectar si estamos en un entorno restrictivo de previsualización (blob)
    const currentUrl = window.location.href;
    setIsBlobUrl(currentUrl.startsWith('blob:') || currentUrl.includes('webcontainer'));

    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
    });
  }, []);

  useEffect(() => {
    localStorage.setItem(MEMORY_KEY, JSON.stringify(chatMessages.slice(-150)));
  }, [chatMessages]);

  useEffect(() => {
    if (isChatVisible) chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages, isChatVisible]);

  const copyAppUrl = () => {
    if (isBlobUrl) {
      alert("ATENCIÓN: Estás viendo VALERIA a través de un enlace temporal. Para poder descargarla, primero debes pulsar el botón 'Open in new window' (icono de flecha arriba a la derecha en AI Studio) y luego copiar la dirección de esa nueva pestaña.");
      return;
    }
    const url = window.location.href;
    navigator.clipboard.writeText(url);
    alert("URL de VALERIA copiada. Pégala en tu navegador Chrome (Android) o Safari (iOS) para instalarla.");
  };

  const handleInstallApp = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') setDeferredPrompt(null);
    } else {
      setShowInstallGuide(true);
    }
  };

  const encode = (bytes: Uint8Array) => {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) binary += String.fromCharCode(bytes[i]);
    return btoa(binary);
  };

  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
    return bytes;
  };

  const decodeAudioData = async (data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number) => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
    return buffer;
  };

  const stopAllAudio = () => {
    audioSourcesRef.current.forEach(source => { try { source.stop(); } catch(e) {} });
    audioSourcesRef.current.clear();
    nextStartTimeRef.current = 0;
    setIsResponding(false);
    setMood('calm');
  };

  const toggleSession = async () => {
    if (isSessionActive) {
      if (liveSessionRef.current) liveSessionRef.current.close();
      setIsSessionActive(false);
      sessionActiveRef.current = false;
      stopAllAudio();
      return;
    }

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      inputAudioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      outputAudioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      await inputAudioCtxRef.current.resume();
      await outputAudioCtxRef.current.resume();

      analyserRef.current = outputAudioCtxRef.current.createAnalyser();
      analyserRef.current.fftSize = 512;
      analyserRef.current.connect(outputAudioCtxRef.current.destination);

      const recentContext = chatMessages.slice(-10).map(m => `${m.role === 'user' ? 'Usuario' : 'Valeria'}: ${m.text}`).join('\n');

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setIsSessionActive(true);
            sessionActiveRef.current = true;
            setMood('calm');
            const source = inputAudioCtxRef.current!.createMediaStreamSource(stream);
            const scriptProcessor = inputAudioCtxRef.current!.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              if (!sessionActiveRef.current) return;
              const inputData = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) int16[i] = inputData[i] * 32768;
              const pcmBlob = { data: encode(new Uint8Array(int16.buffer)), mimeType: 'audio/pcm;rate=16000' };
              sessionPromise.then(s => s.sendRealtimeInput({ media: pcmBlob }));
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputAudioCtxRef.current!.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio) {
              setIsResponding(true);
              setMood('processing');
              const ctx = outputAudioCtxRef.current!;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              const buffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = buffer;
              source.connect(analyserRef.current!);
              source.onended = () => {
                audioSourcesRef.current.delete(source);
                if (audioSourcesRef.current.size === 0) {
                  setIsResponding(false);
                  setMood('calm');
                }
              };
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              audioSourcesRef.current.add(source);
            }
            if (message.serverContent?.interrupted) stopAllAudio();
            if (message.serverContent?.modelTurn) {
                const text = message.serverContent.modelTurn.parts.map(p => p.text).filter(Boolean).join('');
                if (text) setChatMessages(prev => [...prev, { id: Date.now().toString(), role: 'valeria', text, timestamp: new Date() }]);
            }
          },
          onerror: (e) => { setIsSessionActive(false); sessionActiveRef.current = false; },
          onclose: () => { setIsSessionActive(false); sessionActiveRef.current = false; }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } },
          systemInstruction: `Eres VALERIA 6.0. Responde directo, elegante y humano. Contexto reciente: ${recentContext}`,
          outputAudioTranscription: {},
        }
      });
      liveSessionRef.current = await sessionPromise;
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="fixed inset-0 flex flex-col bg-[#010101] text-gray-200 overflow-hidden select-none">
      {/* HUD Superior */}
      <header className="pt-[env(safe-area-inset-top)] px-8 py-4 flex items-center justify-between z-50">
        <div className="flex items-center gap-4">
          <div className={`w-2 h-2 rounded-full transition-all duration-500 ${isSessionActive ? 'bg-blue-500 shadow-[0_0_10px_#3b82f6]' : 'bg-white/10'}`}></div>
          <h1 className="text-[10px] font-bold tracking-[0.4em] uppercase text-gray-400">VALERIA 6.0</h1>
        </div>
        
        <div className="flex gap-2">
          {!isStandalone && (
            <button onClick={handleInstallApp} className={`p-2 transition-all ${isBlobUrl ? 'text-yellow-500 animate-bounce' : 'text-blue-400 animate-pulse'}`} title="Configurar Enlace">
              <i className={`fa-solid ${isBlobUrl ? 'fa-triangle-exclamation' : 'fa-download'} text-sm`}></i>
            </button>
          )}
          <button onClick={() => setIsDashboardVisible(!isDashboardVisible)} className="p-2 text-gray-600 hover:text-blue-400">
            <i className="fa-solid fa-microchip text-xs"></i>
          </button>
          <button onClick={() => setIsChatVisible(!isChatVisible)} className="p-2 text-gray-600 hover:text-blue-400">
            <i className="fa-solid fa-terminal text-xs"></i>
          </button>
        </div>
      </header>

      {/* Orbe Central */}
      <main className="flex-1 flex flex-col items-center justify-center relative touch-none">
        <div className="w-full max-w-[80vw] aspect-square cursor-pointer active:scale-95 transition-transform" onClick={toggleSession}>
          <VoiceVisualizer 
            analyser={analyserRef.current} 
            isListening={isSessionActive && !isResponding} 
            isResponding={isResponding}
            mood={mood}
          />
        </div>
        
        <div className="absolute bottom-24 flex flex-col items-center gap-3 opacity-60">
            <div className={`px-5 py-1.5 rounded-full border text-[9px] font-mono tracking-[0.3em] uppercase transition-all ${isSessionActive ? 'border-blue-500/30 text-blue-400' : 'border-white/5 text-gray-600'}`}>
                {isSessionActive ? (isResponding ? 'Transmisión' : 'Escucha Activa') : 'Núcleo Inactivo'}
            </div>
            {!isSessionActive && <span className="text-[8px] text-gray-800 animate-pulse tracking-widest uppercase">Toque para conectar</span>}
        </div>
      </main>

      {/* Guía de Instalación Reforzada */}
      {showInstallGuide && (
        <div className="fixed inset-0 z-[110] bg-black/95 backdrop-blur-3xl flex items-center justify-center p-6 animate-fade-in">
          <div className="max-w-md w-full glass-panel rounded-3xl p-8 space-y-6">
            <div className="flex justify-between items-start">
              <div>
                <h3 className={`text-xl font-bold mb-1 tracking-tight ${isBlobUrl ? 'text-yellow-400' : 'text-blue-400'}`}>
                  {isBlobUrl ? 'Protocolo de Salida' : 'Enlace Neuronal'}
                </h3>
                <p className="text-[10px] text-gray-500 uppercase tracking-widest font-mono">
                  {isBlobUrl ? 'Entorno de previsualización detectado' : 'Guía de Instalación'}
                </p>
              </div>
              <button onClick={() => setShowInstallGuide(false)} className="text-gray-600 hover:text-white"><i className="fa-solid fa-xmark"></i></button>
            </div>

            {isBlobUrl ? (
              <div className="space-y-6">
                <div className="p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-2xl">
                  <p className="text-xs text-yellow-200 leading-relaxed">
                    <b>ERROR DE ENLACE BLOB:</b> Estás viendo VALERIA dentro de un "contenedor". Los enlaces que empiezan por <i>blob:</i> no se pueden descargar.
                  </p>
                </div>
                <div className="flex gap-4 items-start">
                  <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white text-xs shrink-0 font-bold">1</div>
                  <p className="text-xs text-gray-400">Busca el botón <b>"Open in new window"</b> (icono de flecha <i className="fa-solid fa-arrow-up-right-from-square"></i>) en la parte superior derecha de esta ventana de previsualización.</p>
                </div>
                <div className="flex gap-4 items-start">
                  <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white text-xs shrink-0 font-bold">2</div>
                  <p className="text-xs text-gray-400">Se abrirá una nueva pestaña con una dirección real (no un blob).</p>
                </div>
                <div className="flex gap-4 items-start">
                  <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white text-xs shrink-0 font-bold">3</div>
                  <p className="text-xs text-gray-400">En esa nueva pestaña, vuelve a pulsar este icono de descarga para obtener la URL real e instalarla.</p>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="flex gap-4 items-start">
                  <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400 text-xs shrink-0 font-bold">1</div>
                  <div>
                    <h4 className="text-sm font-bold text-gray-200 mb-1">Copiar Enlace Real</h4>
                    <button onClick={copyAppUrl} className="px-4 py-2 bg-blue-600/20 border border-blue-500/40 rounded-xl text-[10px] font-bold text-blue-400 uppercase tracking-widest hover:bg-blue-600/40 transition-all">
                      Copiar URL de Valeria
                    </button>
                  </div>
                </div>
                <div className="flex gap-4 items-start">
                  <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400 text-xs shrink-0 font-bold">2</div>
                  <p className="text-xs text-gray-400">Abre <b>Chrome</b> o <b>Safari</b> en tu móvil y pega el enlace.</p>
                </div>
                <div className="flex gap-4 items-start">
                  <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400 text-xs shrink-0 font-bold">3</div>
                  <div className="flex-1">
                    <p className="text-xs text-gray-400">Usa la opción <b>"Añadir a pantalla de inicio"</b>.</p>
                  </div>
                </div>
              </div>
            )}

            <button 
              onClick={() => setShowInstallGuide(false)} 
              className="w-full py-4 bg-white/5 hover:bg-white/10 rounded-2xl text-xs font-bold text-gray-400 uppercase tracking-[0.3em] transition-all"
            >
              Entendido
            </button>
          </div>
        </div>
      )}

      {/* Overlays de Sistemas y Chat (Igual que antes) */}
      {isDashboardVisible && (
        <div className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-2xl p-8 overflow-y-auto animate-fade-in">
          <div className="flex items-center justify-between mb-8 border-b border-white/5 pb-4">
            <h2 className="text-[11px] font-bold text-blue-400 uppercase tracking-widest">Estado Biométrico</h2>
            <button onClick={() => setIsDashboardVisible(false)} className="w-10 h-10 flex items-center justify-center rounded-full bg-white/5 text-gray-400"><i className="fa-solid fa-xmark"></i></button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {agents.map(a => <AgentCard key={a.id} status={a} />)}
          </div>
        </div>
      )}

      {isChatVisible && (
        <div className="fixed inset-0 z-[100] bg-[#010101] flex flex-col animate-slide-up">
          <div className="pt-[env(safe-area-inset-top)] px-6 py-4 border-b border-white/5 flex items-center justify-between">
            <h2 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Logs del Sistema</h2>
            <button onClick={() => setIsChatVisible(false)} className="text-gray-600"><i className="fa-solid fa-chevron-down"></i></button>
          </div>
          <div className="flex-1 overflow-y-auto p-6 space-y-6 font-mono text-[11px]">
            {chatMessages.map(msg => (
              <div key={msg.id} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                <div className={`p-4 rounded-2xl max-w-[85%] ${msg.role === 'user' ? 'bg-blue-950/30 text-blue-400 border border-blue-900/30' : 'bg-white/5 text-gray-400 border border-white/5'}`}>
                  {msg.text}
                </div>
              </div>
            ))}
            <div ref={chatEndRef} />
          </div>
          <div className="p-6 pb-[calc(1.5rem+env(safe-area-inset-bottom))] bg-black border-t border-white/5">
             <input 
                type="text" 
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && inputText.trim() && (setChatMessages(prev => [...prev, { id: Date.now().toString(), role: 'user', text: inputText, timestamp: new Date() }]), setInputText(''))}
                placeholder="Enviar comando manual..."
                className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-[12px] text-gray-300 focus:outline-none focus:border-blue-500/50"
             />
          </div>
        </div>
      )}

      <footer className="pb-[env(safe-area-inset-bottom)] h-[calc(2.5rem+env(safe-area-inset-bottom))] flex items-center justify-center text-[7px] font-bold text-gray-800 tracking-[0.5em] uppercase border-t border-white/5 bg-black">
        VALERIA BIOMIMETIC_OS | STANDALONE_CORE
      </footer>

      <style>{`
        @keyframes fade-in { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slide-up { from { transform: translateY(100%); } to { transform: translateY(0); } }
        .animate-fade-in { animation: fade-in 0.4s ease-out; }
        .animate-slide-up { animation: slide-up 0.5s cubic-bezier(0.16, 1, 0.3, 1); }
      `}</style>
    </div>
  );
};

export default App;
