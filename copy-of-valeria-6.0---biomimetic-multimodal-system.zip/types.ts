
export enum CorticalAgentType {
  MEMORY = 'Memoria',
  REASONING = 'Razonamiento',
  EMOTIONAL = 'Emocional',
  ACTIONS = 'Acciones',
  PERCEPTION = 'Percepción',
  PLANNING = 'Planificación',
  MONITOR = 'Monitor'
}

export interface AgentStatus {
  id: CorticalAgentType;
  isActive: boolean;
  load: number; // 0-100
  latency: number; // ms
  health: number; // 0-100
  description: string;
}

export interface SystemMetrics {
  cpuUsage: number;
  gpuUsage: number;
  memoryUsage: number;
  synapticCoherence: number;
  homeostasis: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'valeria';
  text: string;
  timestamp: Date;
  modality?: 'text' | 'image' | 'audio';
  imageUrl?: string;
  thinking?: string;
}

export interface MetacognitionState {
  level: number;
  status: string;
  reflection: string;
}

export type SystemMood = 'calm' | 'analytical' | 'processing' | 'emotional' | 'alert';
