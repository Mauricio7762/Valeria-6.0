
import React from 'react';
import { CorticalAgentType } from './types';

export const AGENT_CONFIGS = {
  [CorticalAgentType.MEMORY]: { icon: <i className="fa-solid fa-database"></i>, color: 'text-blue-400', bg: 'bg-blue-400/10' },
  [CorticalAgentType.REASONING]: { icon: <i className="fa-solid fa-brain"></i>, color: 'text-purple-400', bg: 'bg-purple-400/10' },
  [CorticalAgentType.EMOTIONAL]: { icon: <i className="fa-solid fa-heart"></i>, color: 'text-red-400', bg: 'bg-red-400/10' },
  [CorticalAgentType.ACTIONS]: { icon: <i className="fa-solid fa-bolt"></i>, color: 'text-yellow-400', bg: 'bg-yellow-400/10' },
  [CorticalAgentType.PERCEPTION]: { icon: <i className="fa-solid fa-eye"></i>, color: 'text-green-400', bg: 'bg-green-400/10' },
  [CorticalAgentType.PLANNING]: { icon: <i className="fa-solid fa-map"></i>, color: 'text-cyan-400', bg: 'bg-cyan-400/10' },
  [CorticalAgentType.MONITOR]: { icon: <i className="fa-solid fa-gauge-high"></i>, color: 'text-orange-400', bg: 'bg-orange-400/10' },
};

export const INITIAL_METRICS = {
  cpuUsage: 12,
  gpuUsage: 5,
  memoryUsage: 28,
  synapticCoherence: 98,
  homeostasis: 100
};
